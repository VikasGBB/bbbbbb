package stepDefinations;

import java.util.Iterator;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.*;
import pageobjects.HeaderLink;
import utilities.BaseTest;

public class zheaderlinkDefination extends BaseTest{
	
	public static Logger log= LogManager.getLogger(BaseTest.class.getName());
	
	@When("count and click on the links on the header")
	public void count_and_click_on_the_links_on_the_header() throws InterruptedException {
		HeaderLink hl=new HeaderLink(driver,test);
		WebElement con=hl.Links();
		int n=con.findElements(By.tagName("a")).size();
		System.out.println("Number of links present in the page are:"+n);
		log.info("Number of links present in the page are"+n);
		test.info("Number of links present in the page are"+n);
		
//	    clicking on the link separately
        for(int i=1;i<5;i++)
        {
        	String keytab=Keys.chord(Keys.CONTROL,Keys.ENTER);
        	con.findElements(By.tagName("a")).get(i).sendKeys(keytab);
        	log.info(driver.getTitle());
        }
        
        Thread.sleep(5000L);
	}

	@Then("printing the title of the opened links in the console and logs")
	public void printing_the_title_of_the_opened_links_in_the_console_and_logs() {
		HeaderLink hl=new HeaderLink(driver,test);
		 //getting all tabs title
        Set<String> ab=driver.getWindowHandles();
        Iterator<String> it=ab.iterator();
        while(it.hasNext())
        {
        	driver.switchTo().window(it.next());
        	System.out.println(driver.getTitle());
        	log.info(driver.getTitle());
    	    test.info(driver.getTitle());
    	    
        }
       // driver.close();	
	}
	
}
